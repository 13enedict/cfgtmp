from test_bootstrap import JerichoTest
import time

class LibraryTest(JerichoTest):
    def __clickElem(self, id, pause=0.8):
        self.browser.find_element_by_id(id).click()
        time.sleep(pause)

    def testHomepage(self):
        self.browser.get(self.env['root'])
        self.assertEqual(self.browser.find_element_by_class_name("Heading1").text, "Test Library ", "The homepage header is not correct.")
        recs = self.browser.find_elements_by_css_selector(".TableRecords tr")
        self.assertGreater(len(recs), 1, "There are no records loaded")

    def testSearch(self):
        self.browser.get(self.env['root'])
        search = self.browser.find_element_by_id("LisbonTheme_wt15_block_wtMainContent_TEST_LIBRARY_AT_CW_wt11_block_wtSearchInput")
        search.send_keys("good omens")
        self.__clickElem("LisbonTheme_wt15_block_wtMainContent_TEST_LIBRARY_AT_CW_wt11_block_wt34", 0.5)
        recs = self.browser.find_elements_by_css_selector(".TableRecords tr")
        self.assertEqual(2, len(recs), "Exactly one result was expected")

    def testDetail(self):
        self.browser.get(self.env['root'])
        self.browser.find_element_by_link_text("The Light Fantastic").click()

        title = self.browser.find_element_by_class_name("Heading1")
        self.assertEqual("Book Details", title.text, "The page title hasn't changed to Book Details")

        isbn = self.browser.find_element_by_id("LisbonTheme_wt5_block_wtMainContent_TEST_LIBRARY_AT_CW_wt3_block_wtISBN")
        self.assertEqual("9781245672485", isbn.get_attribute('value'), "The ISBN is not for the expected book")